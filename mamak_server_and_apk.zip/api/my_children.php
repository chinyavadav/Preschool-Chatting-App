<?php
    include("connection.php");
    $children=array();
    if(isset($_GET["acc"])){
        $accountno=mysqli_real_escape_string($conn,$_GET["acc"]);
        if(isset($_GET["pupilid"]) && isset($_GET["delete"])){
            $pupilid=mysqli_real_escape_string($conn,$_GET["pupilid"]);
            $statement="DELETE FROM tblparent_children WHERE fldpupilid='$pupilid' and fldaccountno='$accountno'";
            $query=mysqli_query($conn,$statement) or die(mysqli_error($conn));
            $children["response"]="success";
        }else{
        	$statement="SELECT * FROM tblparent_children JOIN tblpupils ON tblparent_children.fldpupilid=tblpupils.fldpupilid WHERE tblparent_children.fldaccountno='$accountno'";
            $query=mysqli_query($conn,$statement) or die(mysqli_error($conn));
            while($record=mysqli_fetch_assoc($query)){          
                $children[]=$record;
            }
        }
    }
    echo json_encode($children);   
?>