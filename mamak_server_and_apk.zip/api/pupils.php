<?php
    include("connection.php");
    $pupils=array();
    if(isset($_GET["pupilid"]) && isset($_GET["delete"])){
        $pupilid=mysqli_real_escape_string($conn,$_GET["pupilid"]);
        $statement="DELETE FROM tblpupils WHERE fldpupilid='$pupilid'";
        $query=mysqli_query($conn,$statement) or die(mysqli_error($conn));
        $statement="DELETE FROM tblparent_children WHERE fldpupilid='$pupilid'";
        $query=mysqli_query($conn,$statement) or die(mysqli_error($conn));
        $pupils["response"]="success";
    }else{
        $statement="SELECT * FROM tblpupils";
        $query=mysqli_query($conn,$statement) or die(mysqli_error($conn));
        while($record=mysqli_fetch_assoc($query)){
            $pupils[]=$record;
        }
    }
    echo json_encode($pupils);   
?>