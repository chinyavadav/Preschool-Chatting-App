<?php
	include("connection.php");
    if(isset($_GET["acc"])){
        $users=array();
        $accountno=mysqli_real_escape_string($conn,$_GET["acc"]);
        $statement="DELETE FROM tblusers WHERE fldaccountno='$accountno'";
        $query=mysqli_query($conn,$statement) or die(mysqli_error($conn));
        $statement="DELETE FROM tblparent_children WHERE fldaccountno='$accountno'";
        $query=mysqli_query($conn,$statement) or die(mysqli_error($conn));
        $statement="DELETE FROM tblchats WHERE fldto='$accountno' or fldfrom='$accountno'";
        $query=mysqli_query($conn,$statement) or die(mysqli_error($conn));
        $result=Array("response"=>"success");
        echo json_encode($result);
    }
?>