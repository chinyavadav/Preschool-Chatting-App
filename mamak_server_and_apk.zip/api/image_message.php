<?php
    include("connection.php");
    header('Content-Type: application/json');
    if($_SERVER["REQUEST_METHOD"]=="POST"){        
        $postdata = file_get_contents('php://input');
        if (isset($postdata)) {
        	$request = json_decode($postdata);
        	$pupilid=mysqli_real_escape_string($conn,$request->pupilid);
        	$from=mysqli_real_escape_string($conn,$request->accountno);
	        $photo=mysqli_real_escape_string($conn,$request->photo);        
	        $timestamp=time()."000";

	        $stat="SELECT * FROM tblparent_children JOIN tblusers ON tblusers.fldaccountno=tblparent_children.fldaccountno WHERE tblparent_children.fldpupilid='$pupilid'";
	        $qry=mysqli_query($conn,$stat) or die(mysqli_error($conn));
	        while($rec=mysqli_fetch_assoc($qry)){
	        	$to=$rec['fldaccountno'];
	        	$statement="INSERT INTO tblchats VALUES('','$from','$to','$photo','Image','$timestamp')";
		    	$query=mysqli_query($conn,$statement) or die(mysqli_error($conn));
	        }
	        $response=array("response"=>"success");
		}else{
			$response=array("response"=>"failed");
		}	    
	    echo json_encode($response);
	}
		    
?>