<?php
	include("connection.php");
	header('Content-Type: application/json');
	if($_SERVER["REQUEST_METHOD"]=="POST"){		
	    $postdata = file_get_contents("php://input");
	    if (isset($postdata)) {
	        $request = json_decode($postdata);

	        $accountno=generateAccountNo();
	        $firstname=mysqli_real_escape_string($conn,$request->firstname);
	        $surname=mysqli_real_escape_string($conn,$request->surname);
	        $sex=mysqli_real_escape_string($conn,$request->sex);
	        $dob=mysqli_real_escape_string($conn,$request->dob);

	        $statement="INSERT INTO tblpupils VALUES('$accountno','$firstname','$surname','$sex','$dob')";
	        $query=mysqli_query($conn,$statement) or die(mysqli_error($conn));
	        $response=array("response"=>"success","accountno"=>$accountno);
		}else {
	        $response=array("response"=>"failed");
	    }
	    echo json_encode($response);	    
	}

	function failed(){
		$response=array("response"=>"failed");
		echo json_encode($response);
	}

	function generateAccountNo(){
		$alphabet=Array('A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z');
		return "P".date('y').random_int(1000,9999).$alphabet[random_int(0,25)];
	}
?>