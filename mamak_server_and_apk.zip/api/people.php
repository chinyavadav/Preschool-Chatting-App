<?php
	include("connection.php");
    if(isset($_GET["acc"])){
        $users=array();
        $accountno=mysqli_real_escape_string($conn,$_GET["acc"]);
        if(isset($_GET["type"])){
            $type=mysqli_real_escape_string($conn,$_GET["type"]);
            $statement="SELECT * FROM tblusers WHERE fldtype='$type'";
        }else{
            if(isset($_GET["exclude"])){
                $statement="SELECT * FROM tblusers WHERE fldaccountno!='$accountno' and fldaccountno!='11111111'";
            }else{
                $statement="SELECT * FROM tblusers WHERE fldaccountno!='$accountno'";
            }
        }
        $query=mysqli_query($conn,$statement) or die(mysqli_error($conn));
        while($record=mysqli_fetch_assoc($query)){
            $temp=Array();
            $temp["accountno"]=$record['fldaccountno'];
            $temp["phoneno"]=$record['fldphoneno'];
            $temp["firstname"]=$record['fldfirstname'];
            $temp["surname"]=$record['fldsurname'];
            $temp["fullname"]=$record['fldfirstname'].' '.$record['fldsurname'];
            $temp["sex"]=$record['fldsex'];
            $temp["type"]=$record['fldtype'];
            $temp["status"]=$record['fldstatus'];
            $users[]=$temp;
        }
        echo json_encode($users);
    }
?>